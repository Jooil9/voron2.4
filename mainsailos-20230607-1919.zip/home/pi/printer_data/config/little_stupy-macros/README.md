# common-macros

A collection of the macros common to all my printers running Klipper.  More machine-specific macros are available in my [V0 Workbench](https://github.com/simplisticton/v0-workbench-config) and [V2.4 2566](https://github.com/simplisticton/v2-2566config) configs.

Feel free to use anything you find here, but remember, if it breaks, you get to keep the pieces.
